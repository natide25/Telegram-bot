
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

BOT_TOKEN = '7961133740:AAFtlCZUVER_TlMm_XEbmn1RBJhvFHd_Egg'
bot = telebot.TeleBot(BOT_TOKEN)
ADMIN_ID = 7140835798
CHANNEL_USERNAME = "@miniapp2_legend"
VIDEO_MESSAGE_ID = 5

forwarded_message_user_map = {}

@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("💳 Pay to Access", callback_data="pay"))
    bot.send_message(message.chat.id, "You're welcome 🤗", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "pay")
def ask_payment(call):
    bot.send_message(call.message.chat.id, "Please send a screenshot of your payment receipt 🧾")

@bot.message_handler(content_types=['text', 'document', 'video', 'audio', 'sticker'])
def invalid_content(message):
    bot.send_message(message.chat.id, "❌ Please send only a payment screenshot (photo), not other content.")

@bot.message_handler(content_types=['photo'])
def handle_screenshot(message):
    bot.send_message(message.chat.id, "🎉 Screenshot received. It is under review.")

    forwarded = bot.forward_message(ADMIN_ID, message.chat.id, message.message_id)
    forwarded_message_user_map[forwarded.message_id] = message.chat.id

    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("✅ Accept", callback_data=f"accept_{forwarded.message_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"reject_{forwarded.message_id}")
    )
    bot.send_message(ADMIN_ID, "Review this payment screenshot:", reply_to_message_id=forwarded.message_id, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("accept_") or call.data.startswith("reject_"))
def process_review(call):
    decision, msg_id = call.data.split("_")
    user_id = forwarded_message_user_map.get(int(msg_id))

    if not user_id:
        bot.answer_callback_query(call.id, "User not found.")
        return

    if decision == "accept":
        bot.send_message(user_id, "✅ Payment accepted! Here's your video:")
        try:
            bot.forward_message(user_id, from_chat_id=CHANNEL_USERNAME, message_id=VIDEO_MESSAGE_ID)
        except:
            bot.send_message(user_id, "Couldn't forward the video. Contact support.")
    else:
        bot.send_message(user_id, "❌ Payment not accepted. Please send a valid payment screenshot.")

    bot.answer_callback_query(call.id)

bot.polling()
